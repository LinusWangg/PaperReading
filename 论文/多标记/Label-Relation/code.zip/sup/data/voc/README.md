Data directory for PASCAL.

After following all of the data preparation instructions, the top level of this directory should consist of the following files and directories:
* `VOCdevkit/`
* `formatted_train_images.npy`
* `formatted_train_labels.npy`
* `formatted_val_images.npy`
* `formatted_val_labels.npy`