1. Warm-up the model with the ASL loss. Run:

python run_warmup.py --loss_lb asl --lb_ratio 0.05 \
--warmup_epochs 12 --lr 1e-4 --net resnet50 \
--dataset_name coco --dataset_dir ./data --batch_size 16 


2. Train the model with the CAP method. Run:

python run_CAP.py --loss_lb asl --loss_ub asl --lb_ratio 0.05 \
--warmup_epochs 12 --lr 1e-4 --net resnet50 \
--dataset_name coco --dataset_dir ./data \
--init_pos_per 0.1 --init_neg_per 0.2 \
--pos_length 8 --neg_length 4

